<!doctype html>
<html>
    <head>
        <title>Mentimeter</title>
        <link href="style.css" type="text/css" rel="stylesheet" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <link href="style.css" type="text/css" rel="stylesheet" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <?php 
            include_once("testimeter.php");
            $currentUser = User::Load(2);
        ?>

        <script language="javascript" type="text/javascript" src="javascript.js"></script>
    </head>

    <body>
        <section id="menubar">
            <ul>
                <li><a href="https://www.hs-flensburg.de/"> <img src="images/HS.png"/> </a></li>
            </ul>
        </section>
        <header>
            <h1>Testimeter</h1>
        </header>
        
        <nav class="nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="askquestion.php">Frage erstellen</a></li>
                <li><a href="#">Verwaltung</a></li>
                <li><a href="account.php"  class="active">Account</a></li>
                <li><a href="#">Abmelden</a></li>
            </ul>
        </nav>
        
        <section id="main">
            <article>
                <h2>Account ändern</h2>

                <?php
                    if(isset($_POST["ID"])){
                        /* TODO: Fehlermeldung mit JavaScript prüfen lassen */
                        if((!strpos($_POST["email"], "@hs-flensburg.de") && !strpos($_POST["email"], "@fh-flensburg.de"))){
                            echo "<h3>Die angegebene E-Mail " . $_POST["email"] . " ist ungültig!</h3>";
                        }elseif(isset($_POST["currentPassword"])){
                            if($_POST["currentPassword"] != $currentUser->Password){
                                echo "<h3>Das angegebene Passwort ist falsch!</h3>";
                            }elseif($_POST["newPassword"][0] != $_POST["newPassword"][1]){
                                echo "<h3>Die angegebenen Passwörter stimmen nicht überein!</h3>";
                            }
                        }else{

                            $currentDepartment = Department::Load($_POST["department"]);

                            $currentUser->Change(
                                    $_POST["title"],
                                    $_POST["firstName"],
                                    $_POST["lastName"],
                                    $_POST["email"],
                                    $currentDepartment);

                            echo "<h3>Account wurde geändert.</h3>";
                        }
                    }
                ?>

                <form action="account.php" method="POST">
                    <table>
                        <tr>
                            <th>ID</th>
                            <th><input type="text" value="<?php echo $currentUser->__get("id"); ?>" readonly name="ID"></th>
                        </tr>
                        <tr>
                            <th>Titel</th>
                            <th><input type="text" value="<?php echo $currentUser->__get('title'); ?>" name="title"></th>
                        </tr>
                        <tr>
                            <th>Vorname</th>
                            <th><input type="text" value="<?php echo $currentUser->__get("firstname"); ?>" name="firstName"></th>
                        </tr>
                        <tr>
                            <th>Nachname</th>
                            <th><input type="text" value="<?php echo $currentUser->__get("lastname"); ?>" name="lastName"></th>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <th><input type="text" value="<?php echo $currentUser->__get("email"); ?>" name="email"></th>
                        </tr>
                        <tr>
                            <th>Rolle</th>
                            <th><input type="text" value="<?php echo $currentUser->__get("role"); ?>" readonly></th>
                        </tr>
                        <tr>
                            <th>Fachbereich</th>
                            <th>
                                <select name="department">
                                    <?php

                                        $currentDepartment = $currentUser->__get("department");
                                        echo "<option>$currentDepartment</option>";

                                        foreach(Department::GetDepartments() as $departments => $department){
                                            if($department["NAME"] != $currentDepartment){
                                                echo "<option>".$department["NAME"]."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                            </th>
                        </tr>
                        <tr>
                            <th>Passwort ändern</th><th><input type="checkbox" onclick="showPasswordBoxes(this, 'lblPassword[]', 'currentPassword', 'newPassword[]');"/></th>
                        </tr>
                        <tr>
                            <th><label hidden name="lblPassword[]">Aktuelles Passwort</label></th>
                            <th><input type="password" name="currentPassword" hidden></th>
                        </tr>
                        <tr>
                            <th><label hidden name="lblPassword[]">Neues Passwort</label></th>
                            <th><input type="password" name="newPassword[]" hidden></th>
                        </tr>
                        <tr>
                            <th><label hidden name="lblPassword[]">Neues Passwort (Wiederholung)</label></th>
                            <th><input type="password" name="newPassword[]" hidden></th>
                        </tr>
                        <tr>
                            <th><input type="submit" value="Ändern"></th>
                            <th><button>Löschen</button></th>
                        </tr>
                    </table>
                </form>
            </article>
        </section>
    </body>
</html>