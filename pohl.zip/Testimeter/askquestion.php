<!doctype html>
<html>
    <head>
        <title>Mentimeter</title>
        <link href="style.css" type="text/css" rel="stylesheet" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta name="description" content="Create a new question">
        <meta name="author" content="Christoph Pohl">
        <meta charset="utf-8">
        <title>Ask question</title>                    

        <?php
            include_once("DataBase.php");
            $dataBase = new DataBase("localhost", "root", "root", "Testimeter");
        ?>

        <script language="javascript" type="text/javascript" src="javascript.js"></script>
    </head>

   <body>
        <section id="menubar">
            <ul>
                <li><a href="https://www.hs-flensburg.de/"> <img src="images/HS.png"/> </a></li>
            </ul>
        </section>
        <header>
            <h1>Testimeter</h1>
        </header>
        
        <nav class="nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="askquestion.php" class="active">Frage erstellen</a></li>
                <li><a href="#">Verwaltung</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="#">Abmelden</a></li>
            </ul>
        </nav>
        
        <section id="main">
            <article>
                <h2>Neue Umfrage erstellen</h2>
                <form action="newquestion.php" method="post">
                    <table>
                        <tr>
                            <th>Frage</th>
                            <th><input type="text" name="question"/></th>
                            
                        </tr>
                        <tr>
                            <th>Beschreibung</th>
                            <th><textarea name="description" maxlength="1000"></textarea></th>
                            
                        </tr>
                        <tr>
                            <th>Kategorie</th>
                            <th>
                                <select name="category">
                                    <?php
                                        foreach($dataBase->getColumn("SELECT CATNAME FROM T_CATEGORY") as $catName){
                                                echo "<option>".$catName."</option>";
                                        }
                                    ?>
                                </select>
                            </th>
                            
                        </tr>
                        <tr>
                            <th>Antworten</th>
                            <th> 
                                <div id="answers">
                                    <input type="text" name="answer[]" id="answer1" placeholder="Antwortmöglichkeit 1" /><br />
                                    <input type="text" name="answer[]" id="answer2" placeholder="Antwortmöglichkeit 2" onkeydown="addTextbox('answers', this);" /><br />
                                </div>
                            </th>
                        </tr>
                        <tr>
                            <th>Art</th>
                            <th>
                                <input type="radio" name="choice" value="singlechoice" checked="checked"/><label>Single-Choice</label><br />
                                <input type="radio" name="choice" value="multiplechoice"/><label>Multiple-Choice</label>
                            </th>                            
                        </tr>
                        <tr>
                            <th></th>
                            <th><input type="submit" value="Jetzt erstellen &raquo" /></th>
                        </tr>
                    </table>
                </form>
            </article>
        </section>
    </body>
</html>