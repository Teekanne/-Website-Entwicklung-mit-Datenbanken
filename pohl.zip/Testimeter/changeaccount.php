<!doctype html>
<html>
	<head>
		<title>Mentimeter</title>
		<link href="style.css" type="text/css" rel="stylesheet" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                <?php 
                    include_once("testimeter.php");
                    $currentUser = User::Load(2);
                ?>
	</head>
	
	<body>
		<section id="menubar"><ul></ul></section>
		<header>
			<h1>Account ändern</h1>
		</header>
		<nav class="nav">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="askquestion.php">Frage erstellen</a></li>
				<li><a href="verwaltung.php" >Verwaltung</a></li>
				<li><a href="account.php" class="active">Account</a></li>
				<li><a href="#">Abmelden</a></li>
			</ul>
		</nav>
		<section id="main">
			<article>
                            <h2>Account ändern</h2>
                            <form>
                                ID: <input type="text" value="<?php echo $currentUser->__get("id"); ?>" readonly>
                                <br />Titel: <input type="text" value="<?php echo $currentUser->__get('title'); ?>">
                                <br />Vorname: <input type="text" value="<?php echo $currentUser->__get("firstname"); ?>">
                                <br />Nachname: <input type="text" value="<?php echo $currentUser->__get("lastname"); ?>">
                                <br />Email: <input type="text" value="<?php echo $currentUser->__get("email"); ?>">
                                <br />Passwort: <input type="password" value="<?php echo $currentUser->__get("password"); ?>">
                                <br />Rolle: <input type="text" value="<?php echo $currentUser->__get("role"); ?>" readonly>
                                <br />Fachbereich: <input type="text" value="<?php echo $currentUser->__get("department"); ?>">
                                <br /><input type="button" value="Ändern">
                            </form>
                            <br />
			</article>
		</section>
	<body>
</html>