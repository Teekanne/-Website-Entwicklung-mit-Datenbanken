<!doctype html>
<html>
    <head>
        <title>Mentimeter</title>
        <link href="style.css" type="text/css" rel="stylesheet" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    </head>

    <body>
        <section id="menubar">
            <ul>
                <li><a href="https://www.hs-flensburg.de/"> <img src="images/HS.png"/> </a></li>
            </ul>
        </section>
        <header>
            <h1>Testimeter</h1>
        </header>
        
        <nav class="nav">
            <ul>
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="askquestion.php">Frage erstellen</a></li>
                <li><a href="#">Verwaltung</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="#">Abmelden</a></li>
            </ul>
        </nav>
        
        <section id="main">
            <article>
                <h2>Content-Bereich</h2>
                <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
            </article>
        </section>
    </body>
</html>