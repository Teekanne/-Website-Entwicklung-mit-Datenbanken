<?php
class Help_Model extends Model {

    function __construct() {
        
        echo 'Help model';
    }
function example(){
    return 10 + 10;
}
}