</div>
<div id="footer">
    (C) Team 1
</div>
</body>
</html>
