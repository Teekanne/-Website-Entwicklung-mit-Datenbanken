<?php
//bind and use
require 'library/Bootstrap.php';
require 'library/Controller.php';
require 'library/Model.php';
require 'library/View.php';

require 'library/Database.php';
require 'library/Session.php';

require 'config/paths.php';
require 'config/database.php';
 //@TODO: Error Handling
$app = new Bootstrap();

?>
