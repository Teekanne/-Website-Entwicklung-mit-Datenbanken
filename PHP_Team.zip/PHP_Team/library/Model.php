<?php

class Model {
 //@TODO: Error Handling
    function __construct() {
        $this->db = new Database();
    }

}

