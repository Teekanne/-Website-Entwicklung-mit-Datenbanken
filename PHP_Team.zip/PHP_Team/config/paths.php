<?php
 //@TODO: Error Handling
define('URL', 'http://localhost/PHP_Team/');