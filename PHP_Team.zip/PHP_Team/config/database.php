<?php
 //@TODO: Error Handling
define('DB_TYPE', 'mysql');
define('DB_HOST', 'projekt.wi.fh-flensburg.de');
define('DB_NAME', 'projekt2015a');
define('DB_USER', 'projekt2015a');
define('DB_PASS', 'P2016s7');
